package com.sonix;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ExamServlet
 */
@WebServlet("/ExamServlet")
public class ExamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static String[] answers = { "N", "A", "A", "O" };

	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String ans = request.getParameter("answer");
		for (int i = 0; i < answers.length; i++) {
			if (ans.equals(answers[i])) {
				out.print("ture");
				response.sendRedirect("ResultServlet");
			} else {
				out.print("flase");

			}
		}

	}

}
